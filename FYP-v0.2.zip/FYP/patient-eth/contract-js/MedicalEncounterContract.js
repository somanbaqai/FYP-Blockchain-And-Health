 
 
var web3;
var encounter_contract_address = "0x1f4373124638f3880d06fDFFbcf1A3C4B4812825";

var encounter_contractABI = 
[
	{
		"constant": false,
		"inputs": [
			{
				"internalType": "string",
				"name": "heathcare_professional",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "encounter_time",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "patientCnic",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "details",
				"type": "string"
			},
			{
				"internalType": "address",
				"name": "provider",
				"type": "address"
			},
			{
				"internalType": "string",
				"name": "_json",
				"type": "string"
			}
		],
		"name": "setEncounterData",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"constant": true,
		"inputs": [
			{
				"internalType": "string",
				"name": "_PatientCNIC",
				"type": "string"
			}
		],
		"name": "getEncounterData",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "PatientCNIC",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	}
]
if (typeof web3 !== 'undefined') {
    web3 = new Web3(web3.currentProvider);
} else {
    // set the provider you want from Web3.providers
    
    web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));
    
}
//console.log( web3.eth.getAccounts().then(function(response) { accounts = response; console.log(accounts[0]; })));
var accounts;
var account_count;
if(localStorage.getItem("acc_count") === null){
    // alert("null");
    account_count = 1;
    localStorage.setItem("acc_count", account_count);
}

web3.eth.getAccounts().then(function(response) { 
    accounts = response;
    console.log(accounts[0]);
    console.log(accounts);
    web3.eth.defaultAccount =  accounts[0];
});

web3.eth.defaultAccount = web3.eth.accounts[0];
console.log(web3.eth.defaultAccount);
console.log(web3.eth.accounts[0])
var MedicalEncounterContract = new web3.eth.Contract( encounter_contractABI,encounter_contract_address);


//MedicalEncounterContract.createProposal("ADHD", "Foo", 2, {from: web3.eth.defaultAccount, gas:3000000})
