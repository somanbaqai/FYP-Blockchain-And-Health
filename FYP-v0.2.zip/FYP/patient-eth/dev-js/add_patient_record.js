console.log(localStorage.getItem("prov_add")); 

$("#add_record").click(function(){
    
    
    if($('#cnic').val() != "" && $('#appt_time').val() != "" && $('#dr_name').val() != "" && $('#details').val() != ""){
        PatientContract.methods.getPatientAddress($('#cnic').val()).call().then(function(response) { 
    
            console.log(response);
            
            if(!response.toString().includes("0000000000000000000000000000000000000000")){
                
                var $items = $('#dr_name, #appt_time,#cnic,#details ')
                
                var obj = {}
                $items.each(function() {
                    obj[this.id] = $(this).val()
                })
                test =JSON.stringify(obj, null, ' ');
                //test = JSON.stringify(test, null, ' ') ;
                //test = JSON.parse(test)
                //console.log(typeof(JSON.stringify(obj, null, ' ')));
                console.log(test);
                 MedicalEncounterContract.methods.setEncounterData($('#dr_name').val().toString().trim(),$('#appt_time').val().toString().trim(),$('#cnic').val().toString().trim(),$('#details').val().toString().trim(), localStorage.getItem("prov_add"),test).send({ from: web3.eth.defaultAccount, gas: 3000000}).then(function(response) { 
                    console.log(response);
                    alert('Successfully added patient record.');
                    //account_count++;
                    location.reload();
                    //localStorage.setItem("acc_count", account_count);
                }); 
                console.log("successfully ")
            }else {
                alert("Please enter valid/registered patient CNIC number");
            }
        

        });
    } else {
    
        alert("Please enter all details.");
    }
    
    
    
});

$("#perm_data_btn").click(function(){
    
    
    location = "provider_manage_permission.html"
    
});
    $("#logout_btn").click(function (e) { 
        localStorage.removeItem("prov_add"); 
        localStorage.removeItem("prov_email"); 
        location = "index.html";
    
    });

