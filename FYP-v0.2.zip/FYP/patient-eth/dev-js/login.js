 
$("#login").click(function(){

    PatientContract.methods.getPatient($('#email').val(),$('#password').val()).call().then(function(response) { 
    
        console.log(response);
        
        if(response[1] != 0){
            
            alert("successfully login")
            location = "Patient_home.html"
            localStorage.setItem("pat_cnic", $('#email').val());
            localStorage.setItem("pat_add", response[5]);
        }else {
            alert("login failed.");
        }
        

    });
    
    
});
$("#registration").click(function(){

    location = "Signup.html"
    
    
});

$("#login_as_provider").click(function(){

    location = "provider_login.html"
    
    
}); 
$("#register_as_provider").click(function(){

    location = "provider_signup.html"
    
    
});
  
