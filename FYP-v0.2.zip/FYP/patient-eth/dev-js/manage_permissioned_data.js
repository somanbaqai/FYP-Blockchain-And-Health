 
 
    //console.log(localStorage.getItem("pat_cnic"));
    //console.log(MedicalEncounterContract.methods);
    //const utf8 = require('utf8');
    //console.log(utf8);
    try {
            PermissionContract.methods.getProviderPermissionList(localStorage.getItem("prov_email")).call({ from: web3.eth.defaultAccount, gas: 3000000}).then(function(response) { 
        //t = JSON.stringyfy();
       // t = JSON.stringify(, null, " " );
            response = JSON.parse(response);
            console.log(response);
            $.each(response, function (indexInArray, valueOfElement) {
                    console.log(valueOfElement.patient_cnic);
                    cnic = valueOfElement.patient_cnic;
                    MedicalEncounterContract.methods.getEncounterData(valueOfElement.patient_cnic.toString()).call({ from: localStorage.getItem("pat_add"), gas: 3000000}).then(function(response) { 
                        try{
                            response = JSON.parse(response)
                            console.log(response);
                            if(response.length > 0){
                            
                            $.each(response, function (indexInArray, valueOfElement) {
                                console.log(valueOfElement);
                                var htmlStr = "";
                                htmlStr += "<tr>"
                                htmlStr += "<td>" + valueOfElement.cnic + "</td>"
                                htmlStr += "<td>" + valueOfElement.dr_name + "</td>"
                                htmlStr += "<td>" + valueOfElement.appt_time + "</td>"
                                htmlStr += "<td>" + valueOfElement.details + "</td>"
                                htmlStr += "</tr>"
                                $("#pat_record").append(htmlStr);
                            
                            });
                            $("#main_loader").fadeOut();
                            }else {
                                $("#no_pat_data").fadeIn();
                                $("#main_loader").fadeOut();
                            }
                        
                        }catch{
                            $("#no_pat_data").fadeIn();
                                $("#main_loader").fadeOut();
                        }
                        
                        
                        
                        //alert('Successfully added patient record.');
                        //account_count++;
                        //location.reload();
                        //localStorage.setItem("acc_count", account_count);
                    }); 
                
                });
        
       // alert("successfully given permission.");
        //account_count++;
        //location.reload();
                    //localStorage.setItem("acc_count", account_count);
    });
    }catch {
        $("#no_pat_data").fadeIn();
        $("#main_loader").fadeOut();
    }

        $("#logout_btn").click(function (e) { 
            localStorage.removeItem("prov_add"); 
            localStorage.removeItem("prov_email"); 
            location = "index.html";
    
    });

    
    
    
    
    
