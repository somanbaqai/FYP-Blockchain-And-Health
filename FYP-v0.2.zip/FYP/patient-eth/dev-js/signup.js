 

    
//Stop Here & wait for instructor
// var employee = PatientContract.at('0x1b1A1AF6776A7AF1F49454D22Fadc982099Ca011');
console.log(PatientContract);

account_count = localStorage.getItem("acc_count");
$("#change_record").click(function(){
        if($('#name').val() != "" && $('age').val() !== "" && $('#email').val() !== "" && $('#cnic').val() !== "" && $('#DoB').val() !== "" && $('#password').val()) {
            if($('#password').val() == $('#re-type-pass').val()){
             //   web3.eth.defaultAccount = web3.eth.accounts[account_count];
                
                console.log("test" + account_count);
                console.log(accounts[account_count]);
                PatientContract.methods.setPatient($('#name').val(),$('#age').val(),$('#cnic').val(),$('#DoB').val(),$('#email').val(),
                $('#password').val(),accounts[account_count]).send({ from: web3.eth.defaultAccount, gas: 3000000}).then(function(response) { 
                    console.log(response);
                    account_count++;
                    location = "index.html";
                    console.log(account_count);
                    localStorage.setItem("acc_count", account_count);
                    alert('Successfully Registered Patient.');
                  
                });     
            }else {
            
                alert("Password do not match with re-enter password");
            }
            
        }else {
        
            alert("Enter Complete Details");
        }

        

});

    
    

   
