 

    
//Stop Here & wait for instructor
// var employee = PatientContract.at('0x1b1A1AF6776A7AF1F49454D22Fadc982099Ca011');
console.log(ProviderContract);
function randomString(length, chars) {
    var result = '';
    for (var i = length; i > 0; --i) result += chars[Math.floor(Math.random() * chars.length)];
    return result;
}
var rString = randomString(5, '0123456789');
$('#age').val(rString)
account_count = localStorage.getItem("acc_count");
$("#change_record").click(function(){
        if($('#name').val() != "" && $('#age').val() !== "" && $('#email').val() !== "" && $('#cnic').val() !== "" && $('#DoB').val() !== "" && $('#password').val()) {
            if($('#password').val() == $('#re-type-pass').val()){
             //   web3.eth.defaultAccount = web3.eth.accounts[account_count];
                
                console.log("test");
                console.log(accounts[account_count]);
                ProviderContract.methods.setProvider($('#name').val(),$('#age').val(),$('#cnic').val(),$('#DoB').val(),$('#email').val(),
                $('#password').val(),accounts[account_count]).send({ from: web3.eth.defaultAccount, gas: 3000000}).then(function(response) { 
                    console.log(response);
                    alert('Successfully Registered provider.');
                    account_count++;
                    location = "index.html";
                    localStorage.setItem("acc_count", account_count);
                });     
            }else {
            
                alert("Password do not match with re-enter password");
            }
            
        }else {
        
            alert("Enter Complete Details");
        }

        

});

    
    

   
