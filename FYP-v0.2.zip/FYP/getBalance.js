//paste your infura API Key here
let infuraKey = "01a1682dce0a4ade9909448c0aa40904";
//paste your MetaMask Account here
let metamaskWallet = "0x9f160583312eff0B1dD903Bab8DC412D4AdFA305";
let Web3 = require("web3");
//let web3 = new Web3(new Web3.providers.HttpProvider("https://ropsten.infura.io/v3/" + infuraKey));
web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));
//console.log(web3);
//web3.eth.getBalance("0x754B4303d01D62A9D10F7647c42eaa65C83d4523").then(balance => console.log(balance));
//console.log(web3.eth.getTransactionCount("0x754B4303d01D62A9D10F7647c42eaa65C83d4523").then(acct =>console.log(acct));
web3.eth.getTransactionCount("0x754B4303d01D62A9D10F7647c42eaa65C83d4523").then(balance => console.log(balance));

web3.eth.getTransactionCount("0x754B4303d01D62A9D10F7647c42eaa65C83d4523", 'latest', (err, current)=>{
      for (var i=1; i <= current; i++) {
        web3.eth.getBlock(i, (err, res) => {
          console.log(res)
        })
      }
    });
