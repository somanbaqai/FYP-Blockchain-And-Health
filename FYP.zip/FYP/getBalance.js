//paste your infura API Key here
let infuraKey = "01a1682dce0a4ade9909448c0aa40904";
//paste your MetaMask Account here
let metamaskWallet = "0x9f160583312eff0B1dD903Bab8DC412D4AdFA305";
let Web3 = require("web3");
let web3 = new Web3(new Web3.providers.HttpProvider("https://ropsten.infura.io/v3/" + infuraKey));
console.log(web3);
web3.eth.getBalance(metamaskWallet).then(balance => console.log(balance));
