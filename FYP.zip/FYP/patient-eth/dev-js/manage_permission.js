 
 console.log("re");
    $("#give_per_btn").click(function (e) { 
        if($("#prov_email").val() != ""){
            PermissionContract.methods.togglePatientPermission(localStorage.getItem("pat_cnic"),$("#prov_email").val()).send({ from: web3.eth.defaultAccount, gas: 3000000}).then(function(response) { 
                    console.log(response);
                    alert("successfully given permission.");
                    //account_count++;
                    location.reload();
                    //localStorage.setItem("acc_count", account_count);
                });
        
            
        } else {
        
            alert("Enter Provider Email !");
        }
    
    });
    $("#logout_btn").click(function (e) { 
        localStorage.removeItem("pat_cnic"); 
        localStorage.removeItem("pat_add"); 
        location = "index.html";
        
    });
