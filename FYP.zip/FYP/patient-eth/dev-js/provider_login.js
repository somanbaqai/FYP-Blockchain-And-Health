localStorage.removeItem("prov_add"); 
localStorage.removeItem("prov_email");  
$("#login").click(function(){

     ProviderContract.methods.getProvider($('#email').val(),$('#password').val()).call().then(function(response) { 
    
        console.log(response);
        
        if(response[1] != 0){
            
            alert("successfully login")
            location = "ProviderAddEntry.html"
            localStorage.setItem("prov_add", response[5]);
            localStorage.setItem("prov_email", response[4]);
        }else {
            alert("login failed.");
        }
        

    });
    
    
});
$("#registration").click(function(){

    location = "provider_signup.html"
    
    
});
    

$("#login_as_patient").click(function(){

    location = "index.html"
    
    
}); 
$("#register_as_patient").click(function(){

    location = "Signup.html"
    
    
});
  
