 
    console.log(localStorage.getItem("pat_cnic"));
    console.log(MedicalEncounterContract.methods);
    //const utf8 = require('utf8');
    console.log(utf8);
    MedicalEncounterContract.methods.getEncounterData(localStorage.getItem("pat_cnic")).call({ from: localStorage.getItem("pat_add"), gas: 3000000}).then(function(response) { 
        try{
            response = JSON.parse(response)
            console.log(response);
            if(response.length > 0){
            
            $.each(response, function (indexInArray, valueOfElement) {
                console.log(valueOfElement);
                var htmlStr = "";
                htmlStr += "<tr>"
                htmlStr += "<td>" + valueOfElement.dr_name + "</td>"
                htmlStr += "<td>" + valueOfElement.appt_time + "</td>"
                htmlStr += "<td>" + valueOfElement.details + "</td>"
                htmlStr += "</tr>"
                $("#pat_record").append(htmlStr);
            
            });
            $("#main_loader").fadeOut();
            }else {
                $("#no_pat_data").fadeIn();
                $("#main_loader").fadeOut();
            }
         
        }catch{
            $("#no_pat_data").fadeIn();
                $("#main_loader").fadeOut();
        }
        
        
        
        //alert('Successfully added patient record.');
        //account_count++;
        //location.reload();
        //localStorage.setItem("acc_count", account_count);
    }); 
    
    $("#manage_per").click(function (e) { 
        location = "patient_manage_permission.html";
    
    });
    $("#logout_btn").click(function (e) { 
         localStorage.removeItem("pat_cnic"); 
        localStorage.removeItem("pat_add");
        location = "index.html";
             

    });
